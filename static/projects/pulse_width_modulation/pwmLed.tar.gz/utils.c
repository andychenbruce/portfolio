//
//  utils.h
//

#define Assert(x)  bobAssert((x), #x, __FILE__, __LINE__)

static const char *
syserr(void)
{
  return strerror(errno);
}

static void fatal(const char * const fmt, ...)
  __attribute__ ((format(printf, 1, 2)))
  __attribute__ ((noreturn))
  __attribute__ ((cold));

static void
fatal(const char * const fmt, ...)
{
  va_list args;
  va_start(args, fmt);
  vfprintf(stderr, fmt, args);
  fprintf(stderr, "\n");
  va_end(args);
  exit(1);
}

static void epf(const char * const fmt, ...)
  __attribute__ ((format(printf, 1, 2)));
  
static void
epf(const char * const fmt, ...)
{
  va_list args;
  va_start(args, fmt);
  vfprintf(stderr, fmt, args);
  fprintf(stderr, "\n");
  va_end(args);
}

void
bobAssert(int x, const char *s, const char *file, int line)
{
  if (!x) {
    fatal("Assertion failed, %s line %d: %s", file, line, s);
  }
  return;
}
