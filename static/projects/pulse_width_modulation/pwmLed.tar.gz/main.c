//
// pwmLed.c
//

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <sys/mman.h>

typedef uint8_t  UInt8;
typedef uint16_t UInt16;
typedef uint32_t UInt32;
typedef uint64_t UInt64;

typedef  int8_t  SInt8;
typedef  int16_t SInt16;
typedef  int32_t SInt32;
typedef  int64_t SInt64;

static struct {
  volatile UInt32 *gpioRegPtr;
  volatile UInt32 *pwmRegPtr;
  volatile UInt32 *clkRegPtr;
  struct {
    SInt32 dutyCycle_Red;
    SInt32 freqHz_Red;
    SInt32 dutyCycle_Blue;
    SInt32 freqHz_Blue;
  } flags;
} g; 

#include "utils.c"

#define RPI4_PERI_BASE	   0xfe000000
#define RPI3_PERI_BASE	   0x3f000000
//#define RPI3_PERI_BASE	   0x20000000

#define GPIO_BASE_OFFSET  0x200000
#define PWM_BASE_OFFSET   0x20c000
#define CLK_BASE_OFFSET   0x101000

#define CLOCK_RATE 54000000.0
#define MAX_FREQ   18000000

#define PWM_CLK_PASSWORD 0x5a000000
#define BCM2835_PWM_CONTROL 0
#define BCM2835_PWM_STATUS  1
#define BCM2835_PWM0_RANGE  4
#define BCM2835_PWM0_DATA   5

#define	PWMCLK_CNTL 40
#define	PWMCLK_DIV  41
#define BLOCK_SIZE 	(4*1024)
#define SCU static const UInt32
  
// Bits in PWM_CTL - Page 127, BCM2711 ARM Peripherals Manual
#define MSEN_B  15
// Bit 14 is unused.
#define USEF_B  13
#define POLA_B  12
#define SBIT_B  11
#define RPTL_B  10
#define MODE_B  9
#define PWEN_B  8
#define MSEN_A  7
#define CLRF    6
#define USEF_A  5
#define POLA_A  4
#define SBIT_A  3
#define RPTL_A  2
#define MODE_A  1
#define PWEN_A  0

SCU PWM_CTL_RESET = // Bit mask to reset the PWM_CTL register
    (1 << MSEN_B) | // 15 : 0 = PWM smoothing is used. 1 = M/S is used.
    (0 << 14)     | // 14 : Bit 14 is not used.
    (0 << USEF_B) | // 13 : 0 = Don't use Fifo for transmitting
    (0 << POLA_B) | // 12 : 0 = Normal polarity
    (0 << SBIT_B) | // 11 : 0=Low, 1=high when not transmitting
    (0 << RPTL_B) | // 10 : Repeat fifo
    (0 << MODE_B) | // 9  : 0 = PWM mode. 1 = Serializer mode
    (0 << PWEN_B) | // 8  : 0 = Disable PWM channel B
    (1 << MSEN_A) | // 7  : 0 = PWM smoothing is used. 1 = M/S is used.
    (1 << CLRF)   | // 6  : 1 = Clear Fifo.  Write only.
    (0 << USEF_A) | // 5  : 0 = Don't use Fifo for transmitting
    (0 << POLA_A) | // 4  : 0 = Normal polarity
    (0 << SBIT_A) | // 3  : 0=Low, 1=high when not transmitting
    (0 << RPTL_A) | // 2  : Repeat fifo
    (0 << MODE_A) | // 1  : 0 = PWM mode. 1 = Serializer mode
    (0 << PWEN_A);  // 0  : 1 = Enable PWM channel A

// Bits in PWM_STA - Page 129
#define STA2  10 // Channel 2 state
#define STA1   9 // Channel 1 state
#define BERR   8 // Bus Error Flag - W1C (Write 1 to Clear)
//               // Bit 7 is unused
//               // Bit 6 is unused
#define CAP02  5 // Channel 2 Gap Occurred - W1C
#define CAP01  4 // Channel 1 Gap Occurred - W1C
#define RERR1  3 // FIFO Read Error Flag   - W1C
#define WERR1  2 // FIFO Write Error Flag  - W1C
#define EMPT1  1 // FIFO Write Error Flag
#define FULL1  0 // FIFO Write Error Flag

SCU PWM_STA_RESET = // Bit mask to reset the PWM_STA register
  (1 << BERR) |
  (1 << CAP01) |
  (1 << CAP02) |
  (1 << RERR1) |
  (1 << WERR1);

#define GX(x) ((x) / sizeof(UInt32))
#define PX(x) ((x) / sizeof(UInt32))

SCU MS        = 20;  
SCU GPFSEL1   = GX(0x04);
SCU GPCLR0    = GX(0x28);
SCU PWM_CTL   = PX(0x00);
SCU PWM_STA   = PX(0x04);
SCU PWM_DMAC  = PX(0x08);
SCU PWM_RNG_A = PX(0x10);
SCU PWM_DAT_A = PX(0x14);
SCU PWM_RNG_B = PX(0x20);
SCU PWM_DAT_B = PX(0x24);

static const char devmem[] = "/dev/mem";

static void
readFileToBuffer(const char *fn, char *buf, int len)
{
  int fd = open(fn, O_RDONLY);
  if (fd < 0) {
    fatal("Can't open %s: %s", fn, syserr());
  }
  int r = read(fd, buf, len);
  if (r < 0) {
    fatal("Can't read %s: %s", fn, syserr());
  }
  close(fd);
}

static int
isPrefix(const char *pfx, const char *longStr)
{
  int len = strlen(pfx);
  return strncmp(pfx, longStr, len) == 0;
}

static UInt32
getModelInfo(void)
{
  static const char fn[] = "/sys/firmware/devicetree/base/model";
  char modelString[64];
  readFileToBuffer(fn, modelString, sizeof(modelString));
  if (isPrefix("Raspberry Pi 3 ", modelString)) {
    return 3;
  }
  if (isPrefix("Raspberry Pi 4 ", modelString)) {
    return 4;
  }
  fatal("Unsupported RPi model: %s", modelString);
}

//static const char devmem[] = "/dev/mem";

static UInt32 *
mapMem(int fd, UInt32 addr)
{
  void *p = mmap(0, BLOCK_SIZE,
		   PROT_READ|PROT_WRITE,
		   MAP_SHARED,
		   fd, addr);
  if (p == MAP_FAILED) {
    fatal("mmap failed for %s, addr=0x%08x: %s",
	  devmem, addr, syserr());
  }
  return (UInt32 *) p;
}

static void
mapPeriphrialPtrs(void)
{
  int fd = open(devmem, O_RDWR | O_SYNC);
  if (fd < 0) {
    fatal("Can't open %s: %s", devmem, syserr());
  }
  UInt32 model = getModelInfo();
  UInt32 periBase;
  switch (model) {
  case 3: periBase = RPI3_PERI_BASE; break;
  case 4: periBase = RPI4_PERI_BASE; break;
  default: fatal("Unsupported RPi model: %d", model);
  }
  epf("periBase=0x%08x ##########", periBase);
  g.pwmRegPtr  = mapMem(fd, periBase + PWM_BASE_OFFSET);
  g.clkRegPtr  = mapMem(fd, periBase + CLK_BASE_OFFSET);
  g.gpioRegPtr = mapMem(fd, periBase + GPIO_BASE_OFFSET);
  close(fd);
}

static void
pwmEnable(void)
{
  usleep(100); // FIXME - Why is this needed?
  g.pwmRegPtr[PWM_CTL] |= ((1 << PWEN_A) | (1 << PWEN_B));
}

static void
pwmDisable(void)
{
  UInt32 r = g.pwmRegPtr[PWM_STA];
  usleep(MS);
  epf("pwmDisable 1 PWM_STA = 0x%08x", r);
  usleep(MS);
  g.pwmRegPtr[PWM_CTL] = PWM_CTL_RESET;
  g.pwmRegPtr[PWM_STA] = PWM_STA_RESET;
  usleep(MS);
  g.pwmRegPtr[PWM_STA] = PWM_STA_RESET;
  r = g.pwmRegPtr[PWM_STA];
  epf("pwmDisable 2 PWM_STA = 0x%08x", r);
  for (int i = 0; i < 10000; ++i) {
    r = g.pwmRegPtr[PWM_STA];
    if ((r & ((1 << 10) | (1 << 9))) == 0) {
      return;
    }
    usleep(100);
  }
  fatal("pwmDisable - Timeout, PWM_STA=0x%08x", r);
}

static void
pwmReset(void)
{
  SCU PWM_BERR  = 8;
  SCU PWM_GAP02 = 5;
  SCU PWM_GAP01 = 4;
  SCU PWM_RERR  = 3;
  SCU PWM_WERR  = 2;
  SCU ErrMask =
    (1 << PWM_BERR)  |
    (1 << PWM_GAP02) |
    (1 << PWM_GAP01) |
    (1 << PWM_RERR)  |
    (1 << PWM_WERR);
  g.pwmRegPtr[PWM_STA] = ErrMask;
  UInt32 r;
  
  usleep(MS);
  r = g.pwmRegPtr[PWM_STA];
  epf("pwmReset PWM_STA = 0x%08x", r);
  
  usleep(MS);
  
  //  g.pwmRegPtr[PWM_STA] = 0x12345678;
  
  r = g.pwmRegPtr[PWM_STA];
  epf("pwmReset PWM_STA = 0x%08x, ErrMask=0x%08x", r, ErrMask);
  
  Assert((r & ErrMask) == 0);
  pwmDisable();
  r = g.pwmRegPtr[PWM_STA];
  if (r != 2) {
    epf("pwmRegPtr[PWM_STA] = 0x%04x", r);
    epf("pwmRegPtr[PWM_STA] should be 2");
  }
  // Assert(r == 2);
  g.pwmRegPtr[PWM_DAT_A] = 0;
  g.pwmRegPtr[PWM_DAT_B] = 0;
}

static void
clockKill(void)
{
  epf("Killing clock");
  g.clkRegPtr[PWMCLK_CNTL] = 0x5a000000 | (1 << 5) | (1 << 0);
  usleep(MS);
  g.clkRegPtr[PWMCLK_CNTL] = 0x5a000000 | (0 << 5) | (1 << 0);
}

static void
clockDisable(void)
{
  g.clkRegPtr[PWMCLK_CNTL] = 0x5a000001; // Turn OFF enable flag
  for (int i = 0; i < 1000; ++i) {
    usleep(MS);
    if ((g.clkRegPtr[PWMCLK_CNTL] & 0x80) == 0) {
      return;
    }
    clockKill();
  }
  fatal("clockDisable() failed");
}

static void
clockEnable(void)
{
  g.clkRegPtr[PWMCLK_CNTL] = 0x5a000011; // Set source to oscillator and enable clock.
  for (int i = 0; i < 1000; ++i) {
    usleep(MS);
    if ((g.clkRegPtr[PWMCLK_CNTL] & 0x80) != 0) {
      return;
    }
  }
  fatal("clockEnable() failed");
}

static void
gpioInit(void)
{
  UInt32 r;
  r = g.gpioRegPtr[GPFSEL1];
  r &= ~((7 << 6) | (7 << 9)); // Clr Alt funcs for pins 12 & 13
  r |=  ((4 << 6) | (4 << 9)); // PWM Alt funcs for pins 12 & 13
  g.gpioRegPtr[GPFSEL1] = r;
}

static void
gpioOff(void)
{
  UInt32 r;
  r = g.gpioRegPtr[GPFSEL1];
  r &= ~((7 << 6) | (7 << 9)); // Clr Alt funcs for pins 12 & 13
  r |=  ((1 << 6) | (1 << 9)); // Pins 12 & 13 to outputs
  g.gpioRegPtr[GPFSEL1] = r;
  g.gpioRegPtr[GPCLR0] = ((1 << 12) | (1 << 13)); // Pin 12 & 13 = Low
}

static void
checkRegs(int n)
{
  SCU DMA_DISABLED = (0 << 31);
  if (g.pwmRegPtr[PWM_DMAC] != (DMA_DISABLED | (7 << 8) | 7)) {
    epf("g.pwmRegPtr[PWM_DMAC] should be 0x%08x", (DMA_DISABLED | (7 << 8) | 7));
  }
  //  Assert(g.pwmRegPtr[PWM_DMAC] == (DMA_DISABLED | (7 << 8) | 7));
  if (g.pwmRegPtr[PWM_STA] != 2) {
    
    // 10- Channel 2 state
    // 9 - Channel 1 state
    // 8 - Bus Error
    // 7 - 0
    // 6 - 0
    // 5 - Channel 2 Gap Occured
    // 4 - Channel 1 Gap Occured
    // 3 - FIFO Read Error
    // 2 - FIFO Write Error
    // 1 - FIFO Empty
    // 0 - FIFO Full
    
    epf("PWM_STA=0x%08x, n=%d", g.pwmRegPtr[PWM_STA], n);
  }
  epf("PWM_STA=0x%08x, n=%d XX", g.pwmRegPtr[PWM_STA], n);
  //Assert(g.pwmRegPtr[PWM_STA] == 2);
}

//=================================================================
//  These are the functions exported to Python.

void
setPwmClockDiv(UInt32 div)
{
  Assert((div > 0) && (div <= 0xfff));
  clockDisable();
  // 54 = 54 MHz / 54 =  1 MHz
  //  3 = 54 MHz /  3 = 18 MHz
  //  2 = 54 MHz /  2 = 27 MHz
  
  //g.clkRegPtr[PWMCLK_DIV]  = PWM_CLK_PASSWORD | (54 << 12);

  g.clkRegPtr[PWMCLK_DIV]  = PWM_CLK_PASSWORD | (div << 12);
}

static void
pwmInit(void)
{
  epf("pwmInit()");
  //Assert(RPI4_PERI_BASE == bcm_host_get_peripheral_address());
  mapPeriphrialPtrs();
  clockDisable();
  setPwmClockDiv(3); // Set to 54/3 = 18 MHz
  clockEnable();
  pwmReset();
  checkRegs(1);
  gpioInit();
  checkRegs(2);
  epf("PWM_CTL= 0x%08x", g.pwmRegPtr[PWM_CTL]);
}

static void
pwmStart(void)
{
  UInt32 rangeRed = 18000000 / g.flags.freqHz_Red;
  UInt32 rangeBlu = 18000000 / g.flags.freqHz_Blue;
  UInt32 resetRed = rangeRed * g.flags.dutyCycle_Red / 100;
  UInt32 resetBlu = rangeBlu * g.flags.dutyCycle_Blue / 100;
  g.pwmRegPtr[PWM_DAT_A] = resetRed;
  g.pwmRegPtr[PWM_RNG_A] = rangeRed;;
  g.pwmRegPtr[PWM_DAT_B] = resetBlu;
  g.pwmRegPtr[PWM_RNG_B] = rangeBlu;
  pwmEnable();
}

static void
pwmOff(void)
{
  if (g.gpioRegPtr == NULL) {
    Assert(g.clkRegPtr == NULL);
    Assert(g.pwmRegPtr == NULL);
    mapPeriphrialPtrs();
  }
  Assert(g.gpioRegPtr != NULL);
  Assert(g.clkRegPtr != NULL);
  Assert(g.pwmRegPtr != NULL);
  gpioOff();
  //pwmDisable();

  pwmReset();
  clockDisable();
  checkRegs(5);
}

static void
usage(void)
{
  epf("Usage: pwmLed <red-duty-cycle-percent> <red-frequency> <blue-duty-cycle-%%> <blue-freq>");
  epf("     color: \"red\" or \"blue\"");
  epf("duty-cycle: 0 to 100");
  epf(" frequency: Hertz, 1 to 18000000");
  pwmOff();
  exit(1);
}

static void
doCommandLineArgs(int argc, char *argv[])
{
  if ((argc == 2) && (strcmp(argv[1], "off") == 0)) {
    pwmOff();
    exit(0);
  }
  if (argc == 5) {
    g.flags.freqHz_Red     = atoi(argv[1]);
    g.flags.dutyCycle_Red  = atoi(argv[2]);
    g.flags.freqHz_Blue    = atoi(argv[3]);
    g.flags.dutyCycle_Blue = atoi(argv[4]);
    if ((g.flags.dutyCycle_Red < 0) ||
       (g.flags.dutyCycle_Red > 100)) {
      fatal("Bad duty cycle: %d", g.flags.dutyCycle_Red);
    }
    if ((g.flags.dutyCycle_Blue < 0) ||
        (g.flags.dutyCycle_Blue> 100)) {
      fatal("Bad duty cycle: %d", g.flags.dutyCycle_Blue);
    }
    if ((g.flags.freqHz_Red < 1) ||
	  (g.flags.freqHz_Red > MAX_FREQ)) {
      fatal("Bad frequency: %d", g.flags.freqHz_Red);
    }
    if ((g.flags.freqHz_Blue< 1) ||
	  (g.flags.freqHz_Blue > MAX_FREQ)) {
      fatal("Bad frequency: %d", g.flags.freqHz_Blue);
    }
    return;
  }
  usage();
}

int
main(int argc, char *argv[])
{
  doCommandLineArgs(argc, argv);
  pwmInit();
  pwmStart();
  return 0;
}
